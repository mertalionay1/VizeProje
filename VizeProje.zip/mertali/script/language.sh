#!/bin/bash

flutter pub run easy_localization:generate -S assets/translations -O lib/product/init/language -o locale_keys.g.dart -f keys