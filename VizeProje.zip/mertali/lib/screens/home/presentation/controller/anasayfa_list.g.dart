// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'anasayfa_list.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$anasayfaListHash() => r'07f0ef25c2c416faa786b9db5b283331c565189e';

/// See also [AnasayfaList].
@ProviderFor(AnasayfaList)
final anasayfaListProvider =
    AutoDisposeAsyncNotifierProvider<AnasayfaList, List<Oneri>>.internal(
  AnasayfaList.new,
  name: r'anasayfaListProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$anasayfaListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AnasayfaList = AutoDisposeAsyncNotifier<List<Oneri>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
