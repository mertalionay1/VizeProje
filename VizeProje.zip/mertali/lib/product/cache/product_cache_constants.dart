enum ProductCacheConstants {
  themeKey(value: "themeKey"),
  ;

  const ProductCacheConstants({
    required this.value,
  });

  final String value;
}
