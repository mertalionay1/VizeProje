final class ProductServiceConstants {
  static const String baseUrl = "https://reqres.in/api";
}
